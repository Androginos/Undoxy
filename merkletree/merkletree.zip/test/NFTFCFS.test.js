const { expect } = require("chai");
const { ethers } = require("hardhat");

describe("NFTFCFS", function () {
  let nft;
  let owner;
  let addr1;
  let addr2;
  let addrs;
  let snapshotId;

  beforeEach(async function () {
    // Her testten önce snapshot al
    snapshotId = await ethers.provider.send("evm_snapshot", []);

    // EVM'in mevcut blok zamanını al
    const blockNum = await ethers.provider.getBlockNumber();
    const block = await ethers.provider.getBlock(blockNum);
    const currentTime = BigInt(block.timestamp);

    // Contract factory'yi burada tanımla
    const NFTFCFS = await ethers.getContractFactory("NFTFCFS");

    const wlStartTime = currentTime + BigInt(60); // 1 dakika sonra
    const fcfsStartTime = currentTime + BigInt(120); // 2 dakika sonra
    const publicStartTime = currentTime + BigInt(180); // 3 dakika sonra

    [owner, addr1, addr2, ...addrs] = await ethers.getSigners();

    nft = await NFTFCFS.deploy(
      wlStartTime,
      fcfsStartTime,
      publicStartTime,
      [addr1.address], // WL1 listesi
      [addr2.address]  // WL2 listesi
    );
    await nft.waitForDeployment();

    // Zamanı ilerlet
    await ethers.provider.send("evm_increaseTime", [60]);
    await ethers.provider.send("evm_mine");

    // Zamanları kontrol et
    const [blockTime, wlTime, fcfsTime, publicTime] = await nft.getTimes();
    console.log("Block Time:", new Date(Number(blockTime) * 1000).toLocaleString());
    console.log("WL Start Time:", new Date(Number(wlTime) * 1000).toLocaleString());
    console.log("FCFS Start Time:", new Date(Number(fcfsTime) * 1000).toLocaleString());
    console.log("Public Start Time:", new Date(Number(publicTime) * 1000).toLocaleString());
  });

  afterEach(async function () {
    // Her testten sonra snapshot'a geri dön
    await ethers.provider.send("evm_revert", [snapshotId]);
  });

  describe("FCFS Mint", function () {
    it("Should allow FCFS mint for whitelisted address", async function () {
      // FCFS aralığına gir
      let [blockTime, , fcfsTime, publicTime] = await nft.getTimes();
      if (Number(blockTime) < Number(fcfsTime)) {
        await ethers.provider.send("evm_increaseTime", [Number(fcfsTime) - Number(blockTime) + 1]);
        await ethers.provider.send("evm_mine");
      } else if (Number(blockTime) >= Number(publicTime)) {
        throw new Error("Block time FCFS aralığını geçti");
      }

      // Zamanları kontrol et
      [blockTime, , fcfsTime, publicTime] = await nft.getTimes();
      console.log("\nFCFS Mint Test - Zamanlar:");
      console.log("Block Time:", new Date(Number(blockTime) * 1000).toLocaleString());
      console.log("FCFS Start Time:", new Date(Number(fcfsTime) * 1000).toLocaleString());
      console.log("Public Start Time:", new Date(Number(publicTime) * 1000).toLocaleString());

      // FCFS mint işlemini dene
      const mintPrice = await nft.fcfsMintPrice();
      await expect(nft.connect(addr2).mintFCFS({ value: mintPrice }))
        .to.emit(nft, "Transfer")
        .withArgs(ethers.ZeroAddress, addr2.address, 0);

      // Mint durumunu kontrol et
      const hasMinted = await nft.hasMintedFCFS(addr2.address);
      expect(hasMinted).to.be.true;

      // NFT sahipliğini kontrol et
      const owner = await nft.ownerOf(0);
      expect(owner).to.equal(addr2.address);
    });

    it("Should not allow FCFS mint for non-whitelisted address", async function () {
      // FCFS aralığına gir
      let [blockTime, , fcfsTime, publicTime] = await nft.getTimes();
      if (Number(blockTime) < Number(fcfsTime)) {
        await ethers.provider.send("evm_increaseTime", [Number(fcfsTime) - Number(blockTime) + 1]);
        await ethers.provider.send("evm_mine");
      } else if (Number(blockTime) >= Number(publicTime)) {
        throw new Error("Block time FCFS aralığını geçti");
      }

      // Zamanları kontrol et
      [blockTime, , fcfsTime, publicTime] = await nft.getTimes();
      console.log("\nNon-Whitelist Test - Zamanlar:");
      console.log("Block Time:", new Date(Number(blockTime) * 1000).toLocaleString());
      console.log("FCFS Start Time:", new Date(Number(fcfsTime) * 1000).toLocaleString());
      console.log("Public Start Time:", new Date(Number(publicTime) * 1000).toLocaleString());

      // FCFS mint işlemini dene
      const mintPrice = await nft.fcfsMintPrice();
      await expect(nft.connect(addr1).mintFCFS({ value: mintPrice }))
        .to.be.revertedWith("Whitelist 2'de yoksun!");
    });

    it("Should not allow FCFS mint before start time", async function () {
      // FCFS başlamadan önceyiz, garantiye almak için block time'ı fcfsTime'dan 10 saniye önceye çek
      let [blockTime, , fcfsTime, ] = await nft.getTimes();
      if (Number(blockTime) >= Number(fcfsTime)) {
        // Zamanı geri alamayız, test baştan başlasın
        throw new Error("Block time FCFS başlangıcından sonra, test baştan başlatılmalı");
      }
      // Zamanları kontrol et
      [blockTime, , fcfsTime, ] = await nft.getTimes();
      console.log("\nBefore Start Time Test - Zamanlar:");
      console.log("Block Time:", new Date(Number(blockTime) * 1000).toLocaleString());
      console.log("FCFS Start Time:", new Date(Number(fcfsTime) * 1000).toLocaleString());

      const mintPrice = await nft.fcfsMintPrice();
      await expect(nft.connect(addr2).mintFCFS({ value: mintPrice }))
        .to.be.revertedWith("FCFS mint henuz baslamadi");
    });

    it("Should not allow FCFS mint after public start time", async function () {
      // Public aralığına geç
      let [blockTime, , , publicTime] = await nft.getTimes();
      if (Number(blockTime) < Number(publicTime)) {
        await ethers.provider.send("evm_increaseTime", [Number(publicTime) - Number(blockTime) + 1]);
        await ethers.provider.send("evm_mine");
      }
      // Zamanları kontrol et
      [blockTime, , , publicTime] = await nft.getTimes();
      console.log("\nAfter Public Time Test - Zamanlar:");
      console.log("Block Time:", new Date(Number(blockTime) * 1000).toLocaleString());
      console.log("Public Start Time:", new Date(Number(publicTime) * 1000).toLocaleString());

      const mintPrice = await nft.fcfsMintPrice();
      await expect(nft.connect(addr2).mintFCFS({ value: mintPrice }))
        .to.be.revertedWith("FCFS mint sona erdi");
    });

    it("Should not allow double FCFS mint", async function () {
      // FCFS aralığına gir
      let [blockTime, , fcfsTime, publicTime] = await nft.getTimes();
      if (Number(blockTime) < Number(fcfsTime)) {
        await ethers.provider.send("evm_increaseTime", [Number(fcfsTime) - Number(blockTime) + 1]);
        await ethers.provider.send("evm_mine");
      } else if (Number(blockTime) >= Number(publicTime)) {
        throw new Error("Block time FCFS aralığını geçti");
      }
      // Zamanları kontrol et
      [blockTime, , fcfsTime, publicTime] = await nft.getTimes();
      console.log("\nDouble Mint Test - Zamanlar:");
      console.log("Block Time:", new Date(Number(blockTime) * 1000).toLocaleString());
      console.log("FCFS Start Time:", new Date(Number(fcfsTime) * 1000).toLocaleString());
      console.log("Public Start Time:", new Date(Number(publicTime) * 1000).toLocaleString());

      // İlk mint
      const mintPrice = await nft.fcfsMintPrice();
      await nft.connect(addr2).mintFCFS({ value: mintPrice });

      // İkinci mint denemesi
      await expect(nft.connect(addr2).mintFCFS({ value: mintPrice }))
        .to.be.revertedWith("Zaten mint edildi");
    });

    it("Should not allow FCFS mint with insufficient payment", async function () {
      // FCFS aralığına gir
      let [blockTime, , fcfsTime, publicTime] = await nft.getTimes();
      if (Number(blockTime) < Number(fcfsTime)) {
        await ethers.provider.send("evm_increaseTime", [Number(fcfsTime) - Number(blockTime) + 1]);
        await ethers.provider.send("evm_mine");
      } else if (Number(blockTime) >= Number(publicTime)) {
        throw new Error("Block time FCFS aralığını geçti");
      }
      // Zamanları kontrol et
      [blockTime, , fcfsTime, publicTime] = await nft.getTimes();
      console.log("\nInsufficient Payment Test - Zamanlar:");
      console.log("Block Time:", new Date(Number(blockTime) * 1000).toLocaleString());
      console.log("FCFS Start Time:", new Date(Number(fcfsTime) * 1000).toLocaleString());
      console.log("Public Start Time:", new Date(Number(publicTime) * 1000).toLocaleString());

      const mintPrice = await nft.fcfsMintPrice();
      const insufficientPrice = mintPrice - ethers.parseEther("0.1");
      
      await expect(nft.connect(addr2).mintFCFS({ value: insufficientPrice }))
        .to.be.revertedWith("Yetersiz MON");
    });
  });
}); 