require("@nomicfoundation/hardhat-toolbox");
require("dotenv").config();

/** @type import('hardhat/config').HardhatUserConfig */
module.exports = {
  solidity: "0.8.20",
  networks: {
    monad: {
      url: process.env.RPC_URL,
      chainId: 10143,
      accounts: [process.env.PRIVATE_KEY]
    }
  }
};
