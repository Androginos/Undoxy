require("dotenv").config();
const { ethers } = require("hardhat");
const { JsonRpcProvider } = require("ethers");
const fs = require("fs");
const path = require("path");

// deployConfig.json dosyasından ayarları oku
const config = JSON.parse(fs.readFileSync("deployConfig.json", "utf8"));

// Saatleri Unix timestamp'e çevir
function getTimestampFromTime(timeStr) {
    const [hours, minutes] = timeStr.split(':').map(Number);
    const now = new Date();
    const targetDate = new Date(now.getFullYear(), now.getMonth(), now.getDate(), hours, minutes);
    
    // Eğer belirtilen saat geçmişse, bir sonraki güne ayarla
    if (targetDate < now) {
        targetDate.setDate(targetDate.getDate() + 1);
    }
    
    return Math.floor(targetDate.getTime() / 1000);
}

const wlStartTime = getTimestampFromTime(config.wl_start);
const fcfsStartTime = getTimestampFromTime(config.fcfs_start);
const publicStartTime = getTimestampFromTime(config.public_start);

// Whitelist adresleri
const whitelist1Addresses = config.wl1 || [];
const whitelist2Addresses = config.wl2 || [];

// Monad RPC URL
const MONAD_RPC_URL = process.env.RPC_URL;
const provider = new JsonRpcProvider(MONAD_RPC_URL);

async function measureBlockTime() {
  let timestamps = [];
  let blockNumbers = [];
  let elapsed = 0;
  const interval = 3000; // 3 saniye
  const maxDuration = 2 * 60 * 1000; // 2 dakika

  console.log("Blok süresi ölçümü başlatıldı...");
  
  return new Promise((resolve) => {
    const timer = setInterval(async () => {
      const block = await provider.getBlock("latest");
      timestamps.push(block.timestamp);
      blockNumbers.push(block.number);
      console.log("Block:", block.number, "Timestamp:", block.timestamp);

      elapsed += interval;
      if (elapsed >= maxDuration) {
        clearInterval(timer);

        // Ortalama blok süresini hesapla
        let diffs = [];
        for (let i = 1; i < timestamps.length; i++) {
          diffs.push(timestamps[i] - timestamps[i - 1]);
        }
        const avgBlockTime = diffs.reduce((a, b) => a + b, 0) / diffs.length;
        console.log("Ortalama blok süresi (saniye):", avgBlockTime);

        // Zamanları kontrol et
        const lastTimestamp = timestamps[timestamps.length - 1];
        console.log("Son blok zamanı:", lastTimestamp, "UTC:", new Date(lastTimestamp * 1000).toISOString());
        console.log("WL başlangıç zamanı:", wlStartTime, "UTC:", new Date(wlStartTime * 1000).toISOString());
        console.log("FCFS başlangıç zamanı:", fcfsStartTime, "UTC:", new Date(fcfsStartTime * 1000).toISOString());
        console.log("Public başlangıç zamanı:", publicStartTime, "UTC:", new Date(publicStartTime * 1000).toISOString());

        resolve({
          wlStart: wlStartTime,
          fcfsStart: fcfsStartTime,
          publicStart: publicStartTime
        });
      }
    }, interval);
  });
}

async function updateFrontendFiles(contractAddress, whitelist1, whitelist2) {
  try {
    // App.js dosyasını güncelle
    const appJsPath = path.join(__dirname, "..", "..", "Monk-MintPage", "src", "App.js");
    let appJsContent = fs.readFileSync(appJsPath, "utf8");

    // Kontrat adresini güncelle
    appJsContent = appJsContent.replace(
      /const CONTRACT_ADDRESS = ['"].*?['"];/,
      `const CONTRACT_ADDRESS = '${contractAddress}';`
    );

    fs.writeFileSync(appJsPath, appJsContent);
    console.log("App.js dosyası güncellendi");

    // MintButton.js dosyasını güncelle
    const mintButtonPath = path.join(__dirname, "..", "..", "Monk-MintPage", "src", "MintButton.js");
    let mintButtonContent = fs.readFileSync(mintButtonPath, "utf8");

    // Whitelist array'ini güncelle
    const whitelist1Str = JSON.stringify(whitelist1, null, 2);
    const whitelist2Str = JSON.stringify(whitelist2, null, 2);
    
    // Whitelist array'ini değiştir
    mintButtonContent = mintButtonContent.replace(
      /const whitelist = \[[\s\S]*?\];/,
      `const whitelist = ${whitelist1Str};`
    );

    fs.writeFileSync(mintButtonPath, mintButtonContent);
    console.log("MintButton.js dosyası güncellendi");

  } catch (error) {
    console.error("Frontend dosyaları güncellenirken hata:", error);
  }
}

async function deployContract(times) {
  const [deployer] = await ethers.getSigners();
  console.log("\n=== Deploy Bilgileri ===");
  console.log("Deploy eden adres:", deployer.address);
  console.log("Deploy eden bakiyesi:", ethers.formatEther(await deployer.provider.getBalance(deployer.address)), "MON");

  const NFTFCFS = await ethers.getContractFactory("NFTFCFS");
  console.log("\nKontrat deploy ediliyor...");
  
  const contract = await NFTFCFS.deploy(
    times.wlStart,
    times.fcfsStart,
    times.publicStart,
    whitelist1Addresses,
    whitelist2Addresses
  );

  // Kontratın deploy edilmesini bekle
  console.log("Kontrat deploy ediliyor, lütfen bekleyin...");
  await contract.waitForDeployment();
  const contractAddress = await contract.getAddress();

  // Kontrat fonksiyonlarını test et
  console.log("\n=== Kontrat Testleri ===");
  try {
    const wlPrice = await contract.wlMintPrice();
    const fcfsPrice = await contract.fcfsMintPrice();
    const publicPrice = await contract.publicMintPrice();
    
    console.log("WL Mint Fiyatı:", ethers.formatEther(wlPrice), "MON");
    console.log("FCFS Mint Fiyatı:", ethers.formatEther(fcfsPrice), "MON");
    console.log("Public Mint Fiyatı:", ethers.formatEther(publicPrice), "MON");
    
    // Whitelist kontrolleri
    for (const addr of whitelist1Addresses) {
      const isWL1 = await contract.isWhitelist1(addr);
      console.log(`WL1 Kontrol (${addr}):`, isWL1);
    }
    
    for (const addr of whitelist2Addresses) {
      const isWL2 = await contract.isWhitelist2(addr);
      console.log(`WL2 Kontrol (${addr}):`, isWL2);
    }
  } catch (error) {
    console.error("Kontrat test hatası:", error);
  }

  console.log("\n=== Kontrat Bilgileri ===");
  console.log("Kontrat Adresi:", contractAddress);
  console.log("Whitelist Başlangıç:", new Date(times.wlStart * 1000).toLocaleString());
  console.log("FCFS Başlangıç:", new Date(times.fcfsStart * 1000).toLocaleString());
  console.log("Public Başlangıç:", new Date(times.publicStart * 1000).toLocaleString());
  console.log("\nWhitelist 1 adresleri:", whitelist1Addresses);
  console.log("Whitelist 2 adresleri:", whitelist2Addresses);

  // Deploy bilgilerini kaydet
  const deployInfo = {
    contractAddress: contractAddress,
    deployerAddress: deployer.address,
    wlStartTime: times.wlStart,
    fcfsStartTime: times.fcfsStart,
    publicStartTime: times.publicStart,
    whitelist1: whitelist1Addresses,
    whitelist2: whitelist2Addresses,
    deployTime: new Date().toISOString()
  };

  fs.writeFileSync("deployInfo.json", JSON.stringify(deployInfo, null, 2));
  console.log("\nDeploy bilgileri deployInfo.json dosyasına kaydedildi.");

  // === JSON dosyasını frontend'e yaz ===
  const frontendConfigPath = path.join(__dirname, "..", "..", "Monk-MintPage", "public", "config.json");
  fs.writeFileSync(frontendConfigPath, JSON.stringify(deployInfo, null, 2));
  console.log("Frontend config.json dosyasına bilgiler yazıldı.");

  // Frontend dosyalarını güncelle
  console.log("\nFrontend dosyaları güncelleniyor...");
  await updateFrontendFiles(contractAddress, whitelist1Addresses, whitelist2Addresses);
  
  console.log("\n=== Önemli Not ===");
  console.log("1. Kontrat adresini kopyalayın:", contractAddress);
  console.log("2. Bu adresi frontend'de kullanmak için App.js dosyasında güncelleyin");
  console.log("3. deployInfo.json dosyasında tüm bilgiler saklanmıştır");
}

async function main() {
  try {
    // Blok süresini ölç ve zamanları hesapla
    const times = await measureBlockTime();
    
    // Kontratı deploy et
    await deployContract(times);
  } catch (error) {
    console.error("Deploy hatası:", error);
    process.exitCode = 1;
  }
}

main(); 